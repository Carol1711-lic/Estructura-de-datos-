package ed3s6_ejemplo2;

/**
 *
 * @author Rodriguez
 */
public class Llama_Ejemplo2 {
    public static void main(String[] args){
    ED3S6_Ejemplo2 obj = new ED3S6_Ejemplo2();
    obj.suma();
    //obj.mensaje();
    }
}
